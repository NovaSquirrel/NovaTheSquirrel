Double Action Blaster Guys
============

Double Action Blaster Guys is an arcade-style platformer game for the NES that supports up to two players. It has over 25 enemy types, a large assortment of block types, 52 levels and three or four diferent level goal types. An in-game level editor is also included.
